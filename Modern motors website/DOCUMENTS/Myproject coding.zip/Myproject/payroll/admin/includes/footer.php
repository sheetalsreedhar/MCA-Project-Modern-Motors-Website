<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Payroll Process</b>
    </div>
    <strong>Modern Motors</strong>
</footer>